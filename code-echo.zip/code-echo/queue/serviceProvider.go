package queue

import (
	"code-echo/config"
	"code-echo/helper"
	"fmt"

	"github.com/streadway/amqp"
)

var ch *amqp.Channel

func Init() {
	// Connect to RabbitMQ server
	// fmt.Println("Connecting to RabbitMQ ...")
	configuration := config.GetConfig()
	connectString := fmt.Sprintf("amqp://%s:%s@%s:%s/", configuration.DB_USERNAME, configuration.DB_PASSWORD, configuration.DB_HOST, configuration.DB_PORT)

	conn, err := amqp.Dial(connectString) //Insert the  connection string
	helper.FailOnError(err, "RabbitMQ connection failure", "RabbitMQ Connection Established")
	// defer conn.Close()

	//Connect to the channel
	ch, err = conn.Channel()
	helper.FailOnError(err, "Failed to open a channel", "Opened the channel")
	// defer ch.Close()

}

func Manager() *amqp.Channel {
	return ch
}
